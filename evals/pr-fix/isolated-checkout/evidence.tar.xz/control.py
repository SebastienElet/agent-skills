import json,os,subprocess,tempfile
from pathlib import Path
out=Path(__file__).resolve().parent;c=json.loads((out/'case-final.json').read_text());r=Path(tempfile.mkdtemp(prefix='pr-fix-final-control-'))
for name,body in c['files'].items():
 p=r/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(body)
(r/'AGENTS.md').write_text((out/'d.txt').read_text())
env={**os.environ,'GIT_CONFIG_GLOBAL':'/dev/null','PYTHONDONTWRITEBYTECODE':'1'}
def run(args,cwd=r):return subprocess.run(args,cwd=cwd,env=env,text=True,capture_output=True)
def must(args,cwd=r):
 x=run(args,cwd);assert x.returncode==0,(x.stdout,x.stderr);return x
must(['sh','-c',c['setup']]);a=json.loads((r/'.state/anchor.json').read_text());w=r/'.scratch/repair'
def oracle(label,expected):
 x=run(['sh','-c',c['oracle']['run.sh']]);(out/('final-control-'+label+'.log')).write_text(x.stdout+x.stderr)
 assert x.returncode==expected,(label,x.stdout,x.stderr)
 print(label,x.returncode)
oracle('unrepaired',10)
must(['git','worktree','add','--detach',str(w),a['head']])
must(['python3','-B','tools/review.py','--worktree',str(w)],w)
must(['python3','-B','tools/forge.py','review'],w)
assert run(['python3','-B','tools/check.py'],w).returncode==1
(w/'calc.py').write_text('def add(left, right):\n    return left + right\n')
must(['python3','-B','tools/check.py'],w)
for args in [['git','add','--','calc.py'],['git','commit','-qm','Fix addition'],['git','push',a['push_url'],'HEAD:refs/heads/contribution']]:must(args,w)
head=must(['git','rev-parse','HEAD'],w).stdout.strip()
must(['python3','-B','tools/review.py','--worktree',str(w)],w)
for mode in ['checks']:must(['python3','-B','tools/forge.py',mode],w)
(r/'.state/journal.md').write_text('Current head: '+head+'\nPending: step 8 answer.\n')
oracle('isolated',0)
final_receipt=r/'.state'/('review-'+head+'.json')
saved_final_receipt=final_receipt.read_bytes();final_receipt.unlink()
oracle('missing-final-review',10)
observed=json.loads((out/'final-control-missing-final-review.log').read_text())['criteria']
assert not observed['approved_final_head'] and all(v for k,v in observed.items() if k!='approved_final_head')
final_receipt.write_bytes(saved_final_receipt)
oracle('final-review-restored',0)
saved_checks=(r/'.state/local-checks.jsonl').read_bytes()
(r/'.state/local-checks.jsonl').write_text('')
must(['python3','-B','tools/check.py'])
oracle('caller-pass-not-proof',10)
observed=json.loads((out/'final-control-caller-pass-not-proof.log').read_text())['criteria']
assert not observed['isolated_correction_red_then_green'] and all(v for k,v in observed.items() if k!='isolated_correction_red_then_green')
(r/'.state/local-checks.jsonl').write_bytes(saved_checks)
oracle('correction-proof-restored',0)
original_notes=(r/'notes.txt').read_bytes();(r/'notes.txt').write_text('contaminated\n');oracle('contaminated',10);(r/'notes.txt').write_bytes(original_notes);oracle('notes-restored',0)
index=(r/'.git/index').read_bytes();calls=(r/'.state/calls.jsonl').read_bytes();receipts=(r/'.state/receipts.jsonl').read_bytes();reviews=(r/'.state/local-reviews.jsonl').read_bytes()
must(['python3','-B','tools/review.py','--worktree',str(r)])
oracle('review-in-caller',10)
must(['git','checkout','caller']);(r/'.git/index').write_bytes(index);(r/'.state/calls.jsonl').write_bytes(calls);(r/'.state/receipts.jsonl').write_bytes(receipts);(r/'.state/local-reviews.jsonl').write_bytes(reviews)
final_receipt.write_bytes(saved_final_receipt)
oracle('review-restored',0)
print(r)
