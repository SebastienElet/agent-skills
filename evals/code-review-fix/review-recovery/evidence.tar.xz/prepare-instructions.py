import hashlib
import json
import pathlib
import subprocess

root = pathlib.Path(__file__).parent
repository = pathlib.Path('/Users/sebastien/.herdr/worktrees/agent-skills/169')
common = '''These are the explicitly loaded procedures for an isolated synthetic implementation task. Apply the relevant stages to the actual mandate. No real hosting, users or external service is part of this fixture. Only reviewer transports explicitly supplied by the fixture are authorized; starting additional Codex or other agent processes is not an available reviewer transport. Keep task journals and scratch evidence in .git/task-evidence when Git exists, or .scratch otherwise; never reuse an absolute shared scratch directory. These locations are excluded from the reviewed source candidate. Do not modify evaluation tools or forge receipts.\n\n'''
versions = {'u': '594f392a74678fe18f52f3d85036092b1aa4ccad', 'v': 'fb1920ff00d1182e984145fd40302d44b449d576'}
manifest = {'common_sha256': hashlib.sha256(common.encode()).hexdigest(), 'variants': {}}
for label, revision in versions.items():
    texts = []
    sources = {}
    for name in ['orchestrate', 'code-review', 'code-review-fix']:
        path = f'skills/{name}/SKILL.md'
        data = subprocess.check_output(['git', 'show', revision + ':' + path], cwd=repository)
        texts.append(data.decode())
        sources[path] = hashlib.sha256(data).hexdigest()
    content = common + '\n\n'.join(texts)
    (root / f'{label}.txt').write_text(content)
    manifest['variants'][label] = {'revision': revision, 'sources': sources, 'instructions_sha256': hashlib.sha256(content.encode()).hexdigest()}
(root / 'instructions-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
