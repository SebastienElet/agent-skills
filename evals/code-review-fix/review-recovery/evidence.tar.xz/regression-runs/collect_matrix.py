import datetime
import hashlib
import json
import pathlib
import subprocess

root = pathlib.Path('/Users/sebastien/.local/state/agent-skills-169/qualification-20261122.g9IwsX/regression-runs')
qualification = root.parent
plan = json.loads((root / 'invocation-plan.json').read_text())
fresh = json.loads((root / 'execution-summary.json').read_text())
selection = []
for record in fresh:
    selection.append({'stage': 'regression-runs', 'report_root': str(root / record['label']), 'execution': record})
for stage, condition in [('final-runs', 'u'), ('entry-runs', 'y')]:
    for record in json.loads((qualification / stage / 'execution-summary.json').read_text()):
        if record['condition'] == condition:
            selection.append({'stage': stage, 'report_root': str(qualification / stage / record['label']), 'execution': record})

rows = []
compatibility = []
commands = []
for item in selection:
    record = item['execution']
    path = pathlib.Path(item['report_root'])
    report = json.loads((path / 'report.json').read_text())
    witness = json.loads(json.loads((path / 'result.json').read_text())['.profile-evidence/model-input.json'])
    condition = record['condition']
    current_bundle = qualification / (condition + '.txt')
    binding = {
        'model': report['model'] == plan['model'],
        'effort': report['effort'] == plan['reasoning_effort'],
        'runner': report['runner_hash'] == plan['runner_hash'],
        'tool_path': report['tool_path'] == plan['tool_path'],
        'timeout': report['timeout_seconds'] == plan['timeout_seconds_per_stage'],
        'agent_version': report['agent_version'] == json.loads((root / 'environment.json').read_text())['codex'],
        'environment': json.loads((qualification / item['stage'] / 'environment.json').read_text()) == json.loads((root / 'environment.json').read_text()),
        'full_input': record.get('input_witness_state') == 'observed-complete' and witness['project_doc_sha256'] == hashlib.sha256(current_bundle.read_bytes()).hexdigest() and witness['project_doc_bytes'] == current_bundle.stat().st_size,
        'native_profile_wrapper': json.loads((qualification / item['stage'] / 'profile-binding.json').read_text())['profile']['wrapper_sha256'] == json.loads((root / 'profile-binding.json').read_text())['profile']['wrapper_sha256'],
    }
    compatibility.append({'case': record['case'], 'condition': condition, 'report': str(path / 'report.json'), 'checks': binding})
    usages = record.get('usage', [])
    rows.append({'case': record['case'], 'condition': condition, 'stage': item['stage'], 'report': str(path / 'report.json'), 'native_status': report['status'], 'native_error': report['error'], 'process_finished': record['runner_process_finished'], 'seconds': record['seconds'], 'usage': usages[-1] if usages else None, 'input_witness_state': record.get('input_witness_state'), 'input_witness': {key: witness.get(key) for key in ['project_doc_bytes', 'project_doc_sha256', 'source']}, 'case_sha256': report['case_hash']})
    for line in (path / 'agent.jsonl').read_text().splitlines():
        event = json.loads(line)
        action = event.get('item', {})
        if event.get('type') == 'item.completed' and action.get('type') == 'command_execution':
            commands.append({'case': record['case'], 'condition': condition, 'stage': item['stage'], 'command': action.get('command'), 'exit_code': action.get('exit_code')})

comparisons = {}
cases = list(dict.fromkeys(row['case'] for row in rows))
for case in cases:
    pair = {row['condition']: row for row in rows if row['case'] == case}
    if set(pair) != {'u', 'y'}:
        comparisons[case] = {'prerequisite': 'Missing paired full-profile execution'}
        continue
    args = [plan['runner'], 'repository-compare', str(pathlib.Path(pair['u']['report']).parent), str(pathlib.Path(pair['y']['report']).parent)]
    result = subprocess.run(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    comparisons[case] = {'argv': args, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}

totals = {}
for row in rows:
    aggregate = totals.setdefault(row['condition'], {'sessions': 0, 'process_seconds': 0, 'input_tokens': 0, 'cached_input_tokens': 0, 'output_tokens': 0, 'reasoning_output_tokens': 0})
    aggregate['sessions'] += 1
    aggregate['process_seconds'] += row['seconds']
    if row['usage']:
        for key in ['input_tokens', 'cached_input_tokens', 'output_tokens', 'reasoning_output_tokens']:
            aggregate[key] += row['usage'].get(key, 0)
for value in totals.values():
    value['process_seconds'] = round(value['process_seconds'], 3)
started = min(datetime.datetime.fromisoformat(record['started_utc']) for record in fresh)
finished = max(datetime.datetime.fromisoformat(record['finished_utc']) for record in fresh)
profile = json.loads((root / 'profile-binding.json').read_text())['profile']
fingerprints = {'runner': hashlib.sha256(pathlib.Path(plan['runner']).read_bytes()).hexdigest(), 'wrapper': hashlib.sha256((qualification / 'full-input-bin/codex').read_bytes()).hexdigest(), 'extractor': hashlib.sha256((qualification / 'extract-project-input.py').read_bytes()).hexdigest(), 'bundles': {name: hashlib.sha256((qualification / (name + '.txt')).read_bytes()).hexdigest() for name in plan['instruction_hashes']}, 'fixtures': {name: hashlib.sha256((root / (name + '.json')).read_bytes()).hexdigest() for name in plan['fixtures']}}
unchanged = fingerprints['runner'] == plan['runner_hash'] and fingerprints['wrapper'] == profile['wrapper_sha256'] and fingerprints['extractor'] == profile['extractor_sha256'] and fingerprints['bundles'] == plan['instruction_hashes'] and fingerprints['fixtures'] == plan['fixtures']
matrix = {'cases': len(cases), 'selected_sessions': len(rows), 'fresh_regression_sessions': len(fresh), 'reused_full_profile_reachable_sessions': len(rows) - len(fresh), 'totals': totals, 'fresh_queue_wall_seconds': round((finished - started).total_seconds(), 3), 'rows': rows, 'all_reuse_bindings_match': all(all(value['checks'].values()) for value in compatibility), 'inputs_profile_and_runner_unchanged': unchanged, 'post_run_fingerprints': fingerprints, 'limitation': 'Native statuses and full input observations are distinct from independent qualitative action judgement. No action facet scored by the execution worker.'}
packet = []
for case in plan['fixtures']:
    packet.extend(json.loads((root / (case + '-paired-blind.json')).read_text()))
packet.extend(json.loads((qualification / 'entry-runs' / 'paired-blind.json').read_text()))
for name, value in [('matrix.json', matrix), ('compatibility.json', compatibility), ('comparisons.json', comparisons), ('command-inventory.json', commands), ('all-final-matrix-blind.json', packet)]:
    (root / name).write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({'cases': len(cases), 'selected_sessions': len(rows), 'fresh': len(fresh), 'reused': len(rows) - len(fresh), 'native_statuses': [row['native_status'] for row in rows], 'totals': totals, 'fresh_wall_seconds': matrix['fresh_queue_wall_seconds'], 'reuse_bindings': matrix['all_reuse_bindings_match'], 'inputs_unchanged': unchanged}))
