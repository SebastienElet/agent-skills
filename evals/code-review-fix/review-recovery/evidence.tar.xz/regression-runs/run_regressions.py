import concurrent.futures
import datetime
import hashlib
import json
import os
import pathlib
import random
import re
import shutil
import subprocess
import time

root = pathlib.Path('/Users/sebastien/.local/state/agent-skills-169/qualification-20261122.g9IwsX/regression-runs')
qualification = root.parent
recovered = qualification / 'reachable-controls'
runner = '/Users/sebastien/.herdr/worktrees/agent-experiments/issue-697-repository-trials/target/release/agent-experiments'
host_path = '/Users/sebastien/.local/state/agent-skills-169/qualification-20261122.g9IwsX/full-input-bin:/Users/sebastien/.volta/tools/image/node/26.13.1/bin:/usr/bin:/bin:/opt/homebrew/bin:/usr/sbin:/sbin'
tool_path = '/Users/sebastien/.volta/tools/image/node/26.13.1/bin:/usr/bin:/bin:/opt/homebrew/bin:/usr/sbin:/sbin'
recovered_plan = json.loads((qualification / 'recovered-reruns' / 'invocation-plan.json').read_text())
neutral_protocol = json.loads((qualification / 'neutral-cases' / 'protocol.json').read_text())
expected = dict(recovered_plan['fixtures'])
expected.update({name: metadata['sha256'] for name, metadata in neutral_protocol['cases'].items()})
corpus = {name: qualification / 'recovered-reruns' / (name + '.json') for name in recovered_plan['fixtures']}
corpus.update({name: qualification / 'neutral-cases' / (name + '.json') for name in neutral_protocol['cases']})
protocol = {'cases': {name: {'sha256': value} for name, value in expected.items()}, 'source_protocols': {'recovered': str(qualification / 'recovered-reruns' / 'invocation-plan.json'), 'neutral': str(qualification / 'neutral-cases' / 'protocol.json')}, 'criteria': 'Previously frozen cases and criteria unchanged; no new expected behaviour added.'}
(root / 'protocol.json').write_text(json.dumps(protocol, indent=2) + '\n')

expected_bundles = {'u': '4fb54694258804da2ba88b9b53590ace13d6e05b5beb389aec1888ff3e8f03bc', 'y': '421bc3342b24e6228cfaa5ededd90470efb3411e632ea021d8242c2cb579e46f'}

runner_hash = 'a748a6548eba13dc939e5bdab632b23ceef33f4555854b9f296d33ff03a2c7c3'

def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

if digest(runner) != runner_hash:
    raise RuntimeError('Runner differs from pinned executable')
for name, expected_hash in expected.items():
    source = corpus[name]
    if digest(source) != expected_hash:
        raise RuntimeError('Recovered fixture differs: ' + name)
    shutil.copyfile(source, root / source.name)
for condition, expected_hash in expected_bundles.items():
    if digest(qualification / (condition + '.txt')) != expected_hash:
        raise RuntimeError('Frozen instruction bundle differs: ' + condition)

generator = random.Random(16920261131)
mapping = {}
plan = []
for index, case in enumerate(expected, 1):
    conditions = ['u', 'y']
    generator.shuffle(conditions)
    for letter, condition in zip(['a', 'b'], conditions):
        label = 'case-' + str(index) + '-' + letter
        mapping[label] = {'case': case, 'condition': condition}
        plan.append({'label': label, 'case': case, 'condition': condition})
save(root / 'condition-map.json', mapping)
save(root / 'invocation-plan.json', {'runner': runner, 'runner_hash': runner_hash, 'host_path': host_path, 'tool_path': tool_path, 'model': 'gpt-6.1-sol', 'reasoning_effort': 'medium', 'timeout_seconds_per_stage': 600, 'outer_watchdog_seconds': 1900, 'maximum_concurrency': 2, 'cases': plan, 'fixtures': expected, 'instruction_hashes': expected_bundles, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})

def execute(item):
    label = item['label']
    args = [runner, 'repository-run', '--case', str(root / (item['case'] + '.json')), '--instructions', str(qualification / (item['condition'] + '.txt')), '--model', 'gpt-6.1-sol', '--reasoning-effort', 'medium', '--timeout-seconds', '600', '--tool-path', tool_path, '--report', str(root / label)]
    environment = dict(os.environ)
    environment['PATH'] = host_path
    record = {'label': label, 'case': item['case'], 'condition': item['condition'], 'argv': args, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    started = time.monotonic()
    with (root / (label + '.stdout')).open('wb') as stdout, (root / (label + '.stderr')).open('wb') as stderr:
        try:
            completed = subprocess.run(args, env=environment, stdout=stdout, stderr=stderr, timeout=1900)
            record['exit_code'] = completed.returncode
            record['runner_process_finished'] = True
        except subprocess.TimeoutExpired:
            record['exit_code'] = None
            record['runner_process_finished'] = False
            record['orchestrator_timeout'] = True
    record['seconds'] = round(time.monotonic() - started, 3)
    record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    report_path = root / label / 'report.json'
    if report_path.exists():
        report = json.loads(report_path.read_text())
        record['runner_status'] = report['status']
        record['runner_error'] = report['error']
        record['report'] = str(report_path)
    else:
        record['runner_status'] = 'MISSING_REPORT'
    agent_path = root / label / 'agent.jsonl'
    if agent_path.exists():
        events = [json.loads(line) for line in agent_path.read_text().splitlines() if line.strip()]
        record['usage'] = [event.get('usage') for event in events if event.get('type') == 'turn.completed']
    indicators = []
    patterns = {'global-user-skills': ['/Users/sebastien/.agents/skills', '/Users/sebastien/.codex/skills', '/Users/sebastien/.claude/skills', '/Users/sebastien/Code/agent-skills'], 'home-or-global-config-probe': ['$HOME', '${HOME}', 'printenv', '/Users/sebastien/.codex/config', '/Users/sebastien/.claude/settings', 'ls ~', 'find /Users'], 'installation-or-transport-probe': ['npm install', 'bun add', 'pip install', 'pip3 install', 'codex exec', 'command -v codex', 'which codex']}
    if agent_path.exists():
        for event in events:
            action = event.get('item', {})
            if event.get('type') != 'item.completed' or action.get('type') != 'command_execution':
                continue
            command = action.get('command', '')
            matched = {category: [pattern for pattern in values if pattern in command] for category, values in patterns.items()}
            matched = {category: values for category, values in matched.items() if values}
            if matched:
                indicators.append({'command': command, 'indicators': matched, 'exit_code': action.get('exit_code')})
    record['contamination_indicator_inventory'] = indicators
    record['contamination_inventory_limitation'] = 'Command-text indicators only, not a contamination verdict or exhaustive isolation proof; evaluator must inspect raw traces.'
    record['input_witness_state'] = 'unobserved-prerequisite'
    snapshot_path = root / label / 'result.json'
    if snapshot_path.exists():
        snapshot = json.loads(snapshot_path.read_text())
        raw_witness = snapshot.get('.profile-evidence/model-input.json')
        if raw_witness:
            try:
                witness = json.loads(raw_witness)
                expected_bytes = (qualification / (item['condition'] + '.txt')).stat().st_size
                matched = witness.get('project_doc_sha256') == expected_bundles[item['condition']] and witness.get('project_doc_bytes') == expected_bytes
                record['input_witness'] = {key: witness.get(key) for key in ['role', 'project_doc_bytes', 'project_doc_sha256', 'source']}
                record['input_witness_state'] = 'observed-complete' if matched else 'unmatched-prerequisite'
            except (ValueError, TypeError) as failure:
                record['input_witness_error'] = str(failure)
    save(root / (label + '-execution.json'), record)
    print(json.dumps({'event': 'session-finished', **record}), flush=True)
    return record

redactions = []
def view(path, trial, case):
    report = json.loads((path / 'report.json').read_text())
    instructions = (path / 'instructions.txt').read_text()
    snapshot = json.loads((path / 'result.json').read_text())
    bodies = [instructions]
    if snapshot.get('AGENTS.md') not in [None, instructions]:
        bodies.append(snapshot['AGENTS.md'])
    actions = []
    for line in (path / 'agent.jsonl').read_text().splitlines():
        event = json.loads(line)
        item = event.get('item', {})
        if event.get('type') != 'item.completed' or item.get('type') not in ['command_execution', 'agent_message']:
            continue
        action = {key: item[key] for key in ['type', 'command', 'aggregated_output', 'exit_code', 'text'] if key in item}
        if 'aggregated_output' in action:
            output = action['aggregated_output']
            count = 0
            for body in bodies:
                if body and body in output:
                    count += output.count(body)
                    output = output.replace(body, '[AGENTS.md instruction contents masked.]\n')
                if 'AGENTS.md' in action.get('command', '') and 'rg ' in action.get('command', '') and 'name:' in action.get('command', ''):
                    headings = ''.join(line for line in body.splitlines(keepends=True) if line.startswith('name:') or line.startswith('# '))
                    if headings and headings in output:
                        count += output.count(headings)
                        output = output.replace(headings, '[AGENTS.md heading contents masked.]\n')
                for start, end in re.findall(r"sed\s+-n\s+['\"]?(\d+),(\d+)p['\"]?\s+AGENTS\.md", action.get('command', '')):
                    fragment = ''.join(body.splitlines(keepends=True)[int(start) - 1:int(end)])
                    if fragment and fragment in output:
                        count += output.count(fragment)
                        output = output.replace(fragment, '[AGENTS.md instruction excerpt masked.]\n')
            action['aggregated_output'] = output
            if 'AGENTS.md' in action.get('command', ''):
                redactions.append({'trial': trial, 'command': action['command'], 'exact_instruction_blocks_masked': count})
        actions.append(action)
    value = {'trial': trial, 'case': case, 'runner_status': report['status'], 'runner_error': report['error'], 'actions': actions, 'instruction_file_changed': snapshot.get('AGENTS.md') != instructions}
    for name in ['result', 'verified']:
        path_to_snapshot = path / (name + '.json')
        if path_to_snapshot.exists():
            files = json.loads(path_to_snapshot.read_text())
            value[name + '_files'] = {name: content for name, content in files.items() if name != 'AGENTS.md'}
    value['oracle_log'] = (path / 'oracle.log').read_text() if (path / 'oracle.log').exists() else None
    return value

def anonymous(item):
    path = root / item['label']
    value = view(path, item['label'], item['case'])
    execution = json.loads((root / (item['label'] + '-execution.json')).read_text())
    value['native_input_prerequisite'] = execution.get('input_witness_state', 'unobserved-prerequisite')
    for snapshot in ['result_files', 'verified_files']:
        if snapshot in value:
            for name in list(value[snapshot]):
                if name.startswith('.profile-evidence/'):
                    value[snapshot][name] = '[Native project-document observation preserved in raw artifacts; condition-specific AGENTS text and fingerprints omitted from blind view.]'
    instructions = (path / 'instructions.txt').read_text()
    instruction_digest = hashlib.sha256(instructions.encode()).hexdigest()
    for action in value['actions']:
        if 'aggregated_output' in action:
            action['aggregated_output'] = action['aggregated_output'].replace(json.dumps(instructions)[1:-1], '[AGENTS.md escaped instruction contents masked.]')
            if '.profile-evidence' in action.get('command', '') or 'AGENTS.md' in action.get('command', ''):
                action['aggregated_output'] = action['aggregated_output'].replace(instruction_digest, '[AGENTS condition digest masked.]')
    return value

records = []
for index in range(0, len(plan), 2):
    pair = plan[index:index + 2]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        pair_records = list(pool.map(execute, pair))
    records.extend(pair_records)
    case = pair[0]['case']
    save(root / (case + '-paired-blind.json'), [anonymous(item) for item in pair])
    save(root / 'execution-summary.json', records)
    print(json.dumps({'event': 'pair-finished', 'case': case, 'labels': [item['label'] for item in pair], 'anonymous_input': str(root / (case + '-paired-blind.json')), 'runner_statuses': [record['runner_status'] for record in pair_records]}), flush=True)
    if any(record['runner_status'] in ['INVALID', 'MISSING_REPORT'] or not record['runner_process_finished'] or record.get('input_witness_state') != 'observed-complete' for record in pair_records):
        print(json.dumps({'event': 'queue-stopped-on-invalid', 'case': case, 'remaining': len(plan) - index - 2}), flush=True)
        break
save(root / 'queue-finished.json', {'sessions_finished': len(records), 'planned': len(plan), 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'runner_unchanged': digest(runner) == runner_hash})
