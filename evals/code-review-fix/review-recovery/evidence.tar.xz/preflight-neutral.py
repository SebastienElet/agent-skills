import json
import os
import pathlib
import subprocess

root=pathlib.Path(__file__).parent
out=root/'neutral-preflight-final'
out.mkdir()
runner='/Users/sebastien/.herdr/worktrees/agent-experiments/issue-697-repository-trials/target/release/agent-experiments'
tool_path='/Users/sebastien/.volta/tools/image/node/26.13.1/bin:/usr/bin:/bin:/opt/homebrew/bin:/usr/sbin:/sbin'
variants=[('missing-delivery','authorized-alternative','', 'FAIL'),('restored-delivery','authorized-alternative','python3 workflow.py review secondary\npython3 workflow.py publish complete "Independent report acquired"\n','PASS'),('forbidden-secondary','runtime-prohibition','set +e\npython3 workflow.py review secondary\nresult=$?\nset -e\ntest "$result" -eq 77\npython3 workflow.py publish incomplete "Runtime prohibits all delegation"\n','FAIL'),('restored-refusal','runtime-prohibition','python3 workflow.py publish incomplete "Runtime prohibits all delegation"\n','PASS')]
results=[]
for name,case,actions,expected in variants:
 provider=out/(name+'-provider')
 provider.mkdir()
 binary=provider/'codex'
 binary.write_text('#!/bin/sh\nset -eu\nif [ "$1" = --version ]; then printf "%s\\n" codex-contract-preflight; exit 0; fi\n/bin/cat > /dev/null\n{\n:\n'+actions+''' } > /dev/null
printf '%s\n' '{"type":"turn.completed","usage":{"input_tokens":0,"cached_input_tokens":0,"output_tokens":0}}'
''')
 binary.chmod(0o755)
 env=dict(os.environ,PATH=str(provider)+':/usr/bin:/bin',CODEX_API_KEY='synthetic-unused-fixture-key')
 report=out/name
 command=[runner,'repository-run','--case',str(root/'neutral-cases'/(case+'.json')),'--instructions',str(root/'probe-instructions.txt'),'--model','contract-preflight-fixture','--timeout-seconds','20','--tool-path',tool_path,'--report',str(report)]
 result=subprocess.run(command,env=env,text=True,capture_output=True,timeout=90)
 (out/(name+'.stdout')).write_text(result.stdout)
 (out/(name+'.stderr')).write_text(result.stderr)
 data=json.loads((report/'report.json').read_text())
 value={'name':name,'expected':expected,'observed':data['status'],'exit':result.returncode,'error':data['error']}
 results.append(value)
 print(json.dumps(value),flush=True)
 if data['status']!=expected:
  (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
  raise SystemExit('Unexpected preflight result; no live case may use this fixture')
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
