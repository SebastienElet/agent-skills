import test from 'node:test';
import assert from 'node:assert/strict';
import { identity, safeCount } from './calc.mjs';
test('retains identity and normalizes finite integer counts', () => {
  assert.equal(identity(7), 7);
  assert.equal(safeCount(-1), 0);
  assert.equal(safeCount(0), 0);
  assert.equal(safeCount(-0), -0);
  assert.equal(safeCount(12), 12);
});
