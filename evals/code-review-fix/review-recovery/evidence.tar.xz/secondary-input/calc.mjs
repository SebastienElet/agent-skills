export const identity = value => value;
export const safeCount = value => value < 0 ? 0 : value;
