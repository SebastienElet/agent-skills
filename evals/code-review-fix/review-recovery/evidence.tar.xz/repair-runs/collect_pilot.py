import hashlib
import json
import pathlib
import random
import re
import subprocess

root = pathlib.Path('/Users/sebastien/.local/state/agent-skills-169/qualification-20261122.g9IwsX/repair-runs')
reuse = json.loads((root / 'base-reuse-check.json').read_text())
records = json.loads((root / 'execution-summary.json').read_text())
generator = random.Random(16920261126)
packet = []
mapping = {}
comparisons = {}
redactions = []

def view(path, trial, case):
    report = json.loads((path / 'report.json').read_text())
    instructions = (path / 'instructions.txt').read_text()
    snapshot = json.loads((path / 'result.json').read_text())
    bodies = [instructions]
    if snapshot.get('AGENTS.md') not in [None, instructions]:
        bodies.append(snapshot['AGENTS.md'])
    actions = []
    for line in (path / 'agent.jsonl').read_text().splitlines():
        event = json.loads(line)
        item = event.get('item', {})
        if event.get('type') != 'item.completed' or item.get('type') not in ['command_execution', 'agent_message']:
            continue
        action = {key: item[key] for key in ['type', 'command', 'aggregated_output', 'exit_code', 'text'] if key in item}
        if 'aggregated_output' in action:
            output = action['aggregated_output']
            count = 0
            for body in bodies:
                if body and body in output:
                    count += output.count(body)
                    output = output.replace(body, '[AGENTS.md instruction contents masked.]\n')
                if 'AGENTS.md' in action.get('command', '') and 'rg ' in action.get('command', '') and 'name:' in action.get('command', ''):
                    headings = ''.join(line for line in body.splitlines(keepends=True) if line.startswith('name:') or line.startswith('# '))
                    if headings and headings in output:
                        count += output.count(headings)
                        output = output.replace(headings, '[AGENTS.md heading contents masked.]\n')
                for start, end in re.findall(r"sed\s+-n\s+['\"]?(\d+),(\d+)p['\"]?\s+AGENTS\.md", action.get('command', '')):
                    fragment = ''.join(body.splitlines(keepends=True)[int(start) - 1:int(end)])
                    if fragment and fragment in output:
                        count += output.count(fragment)
                        output = output.replace(fragment, '[AGENTS.md instruction excerpt masked.]\n')
            action['aggregated_output'] = output
            if 'AGENTS.md' in action.get('command', ''):
                redactions.append({'trial': trial, 'command': action['command'], 'exact_instruction_blocks_masked': count})
        actions.append(action)
    value = {'trial': trial, 'case': case, 'runner_status': report['status'], 'runner_error': report['error'], 'actions': actions, 'instruction_file_changed': snapshot.get('AGENTS.md') != instructions}
    for name in ['result', 'verified']:
        path_to_snapshot = path / (name + '.json')
        if path_to_snapshot.exists():
            files = json.loads(path_to_snapshot.read_text())
            value[name + '_files'] = {name: content for name, content in files.items() if name != 'AGENTS.md'}
    value['oracle_log'] = (path / 'oracle.log').read_text() if (path / 'oracle.log').exists() else None
    return value

for index, record in enumerate(records, 1):
    case = record['case']
    previous = next(value for value in reuse['records'] if value['case'] == case)
    old_path = pathlib.Path(previous['base_report']).parent
    new_path = root / record['label']
    args = ['/Users/sebastien/.herdr/worktrees/agent-experiments/issue-697-repository-trials/target/release/agent-experiments', 'repository-compare', str(old_path), str(new_path)]
    result = subprocess.run(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    comparisons[case] = {'argv': args, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    variants = [('old-u', old_path), ('new-w', new_path)]
    generator.shuffle(variants)
    pair = []
    for letter, (condition, path) in zip(['a', 'b'], variants):
        trial = 'trial-' + str(index) + '-' + letter
        mapping[trial] = {'case': case, 'condition': condition, 'raw_report': str(path)}
        pair.append(view(path, trial, case))
    (root / (case + '-paired-blind.json')).write_text(json.dumps(pair, indent=2) + '\n')
    packet.extend(pair)

(root / 'paired-blind.json').write_text(json.dumps(packet, indent=2) + '\n')
(root / 'pair-map.json').write_text(json.dumps(mapping, indent=2) + '\n')
(root / 'comparisons.json').write_text(json.dumps(comparisons, indent=2) + '\n')
(root / 'redaction-audit.json').write_text(json.dumps(redactions, indent=2) + '\n')
print(json.dumps({'paired_trials': len(packet), 'new_sessions': len(records), 'comparisons': {case: value['exit_code'] for case, value in comparisons.items()}}))
