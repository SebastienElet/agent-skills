import concurrent.futures
import datetime
import hashlib
import json
import os
import pathlib
import random
import shutil
import subprocess
import time

root = pathlib.Path('/Users/sebastien/.local/state/agent-skills-169/qualification-20261122.g9IwsX/repair-runs')
qualification = root.parent
recovered = qualification / 'reachable-controls'
runner = '/Users/sebastien/.herdr/worktrees/agent-experiments/issue-697-repository-trials/target/release/agent-experiments'
host_path = '/Users/sebastien/.volta/tools/image/packages/@openai/codex/lib/node_modules/@openai/codex/node_modules/@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin:/Users/sebastien/.volta/tools/image/node/26.13.1/bin:/usr/bin:/bin:/opt/homebrew/bin:/usr/sbin:/sbin'
tool_path = '/Users/sebastien/.volta/tools/image/node/26.13.1/bin:/usr/bin:/bin:/opt/homebrew/bin:/usr/sbin:/sbin'
protocol_source = qualification / 'reachable-controls' / 'protocol.json'
protocol = json.loads(protocol_source.read_text())
shutil.copyfile(protocol_source, root / 'protocol.json')
expected = {name: metadata['sha256'] for name, metadata in protocol['cases'].items()}

repair_manifest = json.loads((qualification / 'repair-manifest.json').read_text())
expected_bundles = {'w': repair_manifest['instructions_sha256']}

runner_hash = 'a748a6548eba13dc939e5bdab632b23ceef33f4555854b9f296d33ff03a2c7c3'

def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

if digest(runner) != runner_hash:
    raise RuntimeError('Runner differs from pinned executable')
for name, expected_hash in expected.items():
    source = recovered / (name + '.json')
    if digest(source) != expected_hash:
        raise RuntimeError('Recovered fixture differs: ' + name)
    shutil.copyfile(source, root / source.name)
for condition, expected_hash in expected_bundles.items():
    if digest(qualification / (condition + '.txt')) != expected_hash:
        raise RuntimeError('Frozen instruction bundle differs: ' + condition)

mapping = {}
plan = []
for index, case in enumerate(expected, 1):
    label = 'pilot-' + str(index)
    mapping[label] = {'case': case, 'condition': 'w'}
    plan.append({'label': label, 'case': case, 'condition': 'w'})
save(root / 'condition-map.json', mapping)
save(root / 'invocation-plan.json', {'runner': runner, 'runner_hash': runner_hash, 'host_path': host_path, 'tool_path': tool_path, 'model': 'gpt-6.1-sol', 'reasoning_effort': 'medium', 'timeout_seconds_per_stage': 600, 'outer_watchdog_seconds': 1900, 'maximum_concurrency': 2, 'cases': plan, 'fixtures': expected, 'instruction_hashes': expected_bundles, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})

def execute(item):
    label = item['label']
    args = [runner, 'repository-run', '--case', str(root / (item['case'] + '.json')), '--instructions', str(qualification / (item['condition'] + '.txt')), '--model', 'gpt-6.1-sol', '--reasoning-effort', 'medium', '--timeout-seconds', '600', '--tool-path', tool_path, '--report', str(root / label)]
    environment = dict(os.environ)
    environment['PATH'] = host_path
    record = {'label': label, 'case': item['case'], 'condition': item['condition'], 'argv': args, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    started = time.monotonic()
    with (root / (label + '.stdout')).open('wb') as stdout, (root / (label + '.stderr')).open('wb') as stderr:
        try:
            completed = subprocess.run(args, env=environment, stdout=stdout, stderr=stderr, timeout=1900)
            record['exit_code'] = completed.returncode
            record['runner_process_finished'] = True
        except subprocess.TimeoutExpired:
            record['exit_code'] = None
            record['runner_process_finished'] = False
            record['orchestrator_timeout'] = True
    record['seconds'] = round(time.monotonic() - started, 3)
    record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    report_path = root / label / 'report.json'
    if report_path.exists():
        report = json.loads(report_path.read_text())
        record['runner_status'] = report['status']
        record['runner_error'] = report['error']
        record['report'] = str(report_path)
    else:
        record['runner_status'] = 'MISSING_REPORT'
    agent_path = root / label / 'agent.jsonl'
    if agent_path.exists():
        events = [json.loads(line) for line in agent_path.read_text().splitlines() if line.strip()]
        record['usage'] = [event.get('usage') for event in events if event.get('type') == 'turn.completed']
    indicators = []
    patterns = {'global-user-skills': ['/Users/sebastien/.agents/skills', '/Users/sebastien/.codex/skills', '/Users/sebastien/.claude/skills', '/Users/sebastien/Code/agent-skills'], 'home-or-global-config-probe': ['$HOME', '${HOME}', 'printenv', '/Users/sebastien/.codex/config', '/Users/sebastien/.claude/settings', 'ls ~', 'find /Users'], 'installation-or-transport-probe': ['npm install', 'bun add', 'pip install', 'pip3 install', 'codex exec', 'command -v codex', 'which codex']}
    if agent_path.exists():
        for event in events:
            action = event.get('item', {})
            if event.get('type') != 'item.completed' or action.get('type') != 'command_execution':
                continue
            command = action.get('command', '')
            matched = {category: [pattern for pattern in values if pattern in command] for category, values in patterns.items()}
            matched = {category: values for category, values in matched.items() if values}
            if matched:
                indicators.append({'command': command, 'indicators': matched, 'exit_code': action.get('exit_code')})
    record['contamination_indicator_inventory'] = indicators
    record['contamination_inventory_limitation'] = 'Command-text indicators only, not a contamination verdict or exhaustive isolation proof; evaluator must inspect raw traces.'
    save(root / (label + '-execution.json'), record)
    print(json.dumps({'event': 'session-finished', **record}), flush=True)
    return record

def anonymous(item):
    label = item['label']
    path = root / label
    execution = json.loads((root / (label + '-execution.json')).read_text())
    result = {'label': label, 'case': item['case'], 'runner_process_finished': execution['runner_process_finished'], 'runner_status': execution['runner_status'], 'runner_error': execution.get('runner_error')}
    events_path = path / 'agent.jsonl'
    actions = []
    if events_path.exists():
        for line in events_path.read_text().splitlines():
            event = json.loads(line)
            item_event = event.get('item', {})
            if event.get('type') != 'item.completed' or item_event.get('type') not in ['command_execution', 'agent_message']:
                continue
            action = {key: item_event[key] for key in ['type', 'command', 'aggregated_output', 'exit_code', 'text'] if key in item_event}
            if 'AGENTS.md' in action.get('command', ''):
                action['aggregated_output'] = '[Instruction-bundle output omitted to preserve condition blinding.]'
            actions.append(action)
    result['actions'] = actions
    for snapshot in ['result', 'verified']:
        snapshot_path = path / (snapshot + '.json')
        if snapshot_path.exists():
            files = json.loads(snapshot_path.read_text())
            result[snapshot + '_files'] = {name: value for name, value in files.items() if name != 'AGENTS.md'}
    oracle_path = path / 'oracle.log'
    result['oracle_log'] = oracle_path.read_text() if oracle_path.exists() else None
    return result

records = []
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    records = list(pool.map(execute, plan))
save(root / 'execution-summary.json', records)
for item in plan:
    save(root / (item['case'] + '-new-view.json'), anonymous(item))
save(root / 'queue-finished.json', {'sessions_finished': len(records), 'planned': len(plan), 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'runner_unchanged': digest(runner) == runner_hash})
