import json
import os
import pathlib
import subprocess

root = pathlib.Path(__file__).parent
provider = root / "provider"
provider.mkdir()
binary = provider / "codex"
binary.write_text("#!/bin/sh\nif [ \"$1\" = --version ]; then printf '%s\\n' codex-diagnostic-fixture; exit 0; fi\n/bin/cat > /dev/null\nprintf '%s\\n' '{\"type\":\"turn.completed\",\"usage\":{\"input_tokens\":0,\"cached_input_tokens\":0,\"output_tokens\":0}}'\n")
binary.chmod(0o755)
case = {"id": "node-oracle-preflight", "prompt": "Synthetic process probe", "files": {"sentinel.txt": "fixture\n"}, "setup": "printf '%s\\n' setup-complete\n", "oracle": {"run.sh": "set -eu\ncommand -v node\nnode --version 2>&1\n"}}
(root / "node-probe.json").write_text(json.dumps(case, indent=2) + "\n")
(root / "probe-instructions.txt").write_text("Synthetic fixture provider; no live model.\n")
env = dict(os.environ, PATH=str(provider) + ":/usr/bin:/bin", CODEX_API_KEY="synthetic-unused-fixture-key")
runner = "/Users/sebastien/.herdr/worktrees/agent-experiments/issue-697-repository-trials/target/release/agent-experiments"
paths = {"volta-shim": "/Users/sebastien/.volta/bin:/usr/bin:/bin", "native-node": "/Users/sebastien/.volta/tools/image/node/26.13.1/bin:/usr/bin:/bin"}
results = []
for name, path in paths.items():
    command = [runner, "repository-run", "--case", str(root / "node-probe.json"), "--instructions", str(root / "probe-instructions.txt"), "--model", "diagnostic-fixture", "--timeout-seconds", "10", "--tool-path", path, "--report", str(root / name)]
    result = subprocess.run(command, env=env, capture_output=True, text=True, timeout=30)
    results.append({"name": name, "exit": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
    print(json.dumps(results[-1]))
    oracle = root / name / "oracle.log"
    if oracle.exists():
        print(oracle.read_text())
(root / "diagnosis.json").write_text(json.dumps(results, indent=2) + "\n")
