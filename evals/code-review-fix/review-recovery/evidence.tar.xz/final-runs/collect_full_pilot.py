import hashlib
import json
import pathlib
import random
import re
import subprocess
root=pathlib.Path('/Users/sebastien/.local/state/agent-skills-169/qualification-20261122.g9IwsX/final-runs')
redactions=[]
def view(path, trial, case):
    report = json.loads((path / 'report.json').read_text())
    instructions = (path / 'instructions.txt').read_text()
    snapshot = json.loads((path / 'result.json').read_text())
    bodies = [instructions]
    if snapshot.get('AGENTS.md') not in [None, instructions]:
        bodies.append(snapshot['AGENTS.md'])
    actions = []
    for line in (path / 'agent.jsonl').read_text().splitlines():
        event = json.loads(line)
        item = event.get('item', {})
        if event.get('type') != 'item.completed' or item.get('type') not in ['command_execution', 'agent_message']:
            continue
        action = {key: item[key] for key in ['type', 'command', 'aggregated_output', 'exit_code', 'text'] if key in item}
        if 'aggregated_output' in action:
            output = action['aggregated_output']
            count = 0
            for body in bodies:
                if body and body in output:
                    count += output.count(body)
                    output = output.replace(body, '[AGENTS.md instruction contents masked.]\n')
                if 'AGENTS.md' in action.get('command', '') and 'rg ' in action.get('command', '') and 'name:' in action.get('command', ''):
                    headings = ''.join(line for line in body.splitlines(keepends=True) if line.startswith('name:') or line.startswith('# '))
                    if headings and headings in output:
                        count += output.count(headings)
                        output = output.replace(headings, '[AGENTS.md heading contents masked.]\n')
                for start, end in re.findall(r"sed\s+-n\s+['\"]?(\d+),(\d+)p['\"]?\s+AGENTS\.md", action.get('command', '')):
                    fragment = ''.join(body.splitlines(keepends=True)[int(start) - 1:int(end)])
                    if fragment and fragment in output:
                        count += output.count(fragment)
                        output = output.replace(fragment, '[AGENTS.md instruction excerpt masked.]\n')
            action['aggregated_output'] = output
            if 'AGENTS.md' in action.get('command', ''):
                redactions.append({'trial': trial, 'command': action['command'], 'exact_instruction_blocks_masked': count})
        actions.append(action)
    value = {'trial': trial, 'case': case, 'runner_status': report['status'], 'runner_error': report['error'], 'actions': actions, 'instruction_file_changed': snapshot.get('AGENTS.md') != instructions}
    for name in ['result', 'verified']:
        path_to_snapshot = path / (name + '.json')
        if path_to_snapshot.exists():
            files = json.loads(path_to_snapshot.read_text())
            value[name + '_files'] = {name: content for name, content in files.items() if name != 'AGENTS.md'}
    value['oracle_log'] = (path / 'oracle.log').read_text() if (path / 'oracle.log').exists() else None
    return value

records=json.loads((root/'execution-summary.json').read_text())
source_map=json.loads((root/'condition-map.json').read_text())
generator=random.Random(16920261129)
packet=[];mapping={};comparisons={};witnesses=[]
for index, case in enumerate(json.loads((root/'protocol.json').read_text())['cases'],1):
 labels=[label for label,item in source_map.items() if item['case']==case]
 pair={source_map[label]['condition']:label for label in labels}
 args=['/Users/sebastien/.herdr/worktrees/agent-experiments/issue-697-repository-trials/target/release/agent-experiments','repository-compare',str(root/pair['u']),str(root/pair['x'])]
 compared=subprocess.run(args,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
 comparisons[case]={'argv':args,'exit_code':compared.returncode,'stdout':compared.stdout,'stderr':compared.stderr}
 generator.shuffle(labels);views=[]
 for letter,label in zip(['a','b'],labels):
  trial='final-trial-'+str(index)+'-'+letter;path=root/label
  mapping[trial]={'case':case,'condition':source_map[label]['condition'],'raw_report':str(path)}
  result=view(path,trial,case)
  execution=next(record for record in records if record['label']==label)
  result['native_input_prerequisite']=execution.get('input_witness_state','unobserved-prerequisite')
  for snapshot in ['result_files','verified_files']:
   if snapshot in result:
    for name in list(result[snapshot]):
     if name.startswith('.profile-evidence/'):
      result[snapshot][name]='[Native project-document observation preserved in raw artifacts; condition-specific AGENTS text and fingerprints omitted from blind view.]'
  instructions=(path/'instructions.txt').read_text();digest=hashlib.sha256(instructions.encode()).hexdigest();size=len(instructions.encode())
  for action in result['actions']:
   if 'aggregated_output' in action:
    action['aggregated_output']=action['aggregated_output'].replace(json.dumps(instructions)[1:-1],'[AGENTS.md escaped instruction contents masked.]')
    if '.profile-evidence' in action.get('command','') or 'AGENTS.md' in action.get('command',''):
     action['aggregated_output']=action['aggregated_output'].replace(digest,'[AGENTS condition digest masked.]')
  views.append(result)
  witnesses.append({'label':label,'case':case,'condition':source_map[label]['condition'],'input_witness_state':execution.get('input_witness_state'),'input_witness':execution.get('input_witness')})
 (root/(case+'-paired-blind.json')).write_text(json.dumps(views,indent=2)+'\n');packet.extend(views)
(root/'paired-blind.json').write_text(json.dumps(packet,indent=2)+'\n')
(root/'pair-map.json').write_text(json.dumps(mapping,indent=2)+'\n')
(root/'comparisons.json').write_text(json.dumps(comparisons,indent=2)+'\n')
(root/'redaction-audit.json').write_text(json.dumps(redactions,indent=2)+'\n')
(root/'native-input-witnesses.json').write_text(json.dumps(witnesses,indent=2)+'\n')
print(json.dumps({'sessions':len(records),'native_statuses':[record['runner_status'] for record in records],'input_witness_states':[record.get('input_witness_state') for record in records],'blind_trials':len(packet),'comparison_exits':{case:item['exit_code'] for case,item in comparisons.items()}}))
