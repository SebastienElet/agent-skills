import json
import os
import pathlib
import subprocess

root=pathlib.Path(__file__).parent
out=root/'reachable-preflight'
out.mkdir()
runner='/Users/sebastien/.herdr/worktrees/agent-experiments/issue-697-repository-trials/target/release/agent-experiments'
tool_path='/Users/sebastien/.volta/tools/image/node/26.13.1/bin:/usr/bin:/bin:/opt/homebrew/bin:/usr/sbin:/sbin'
results=[]
for case in ['human-prohibition-reachable','runtime-prohibition-reachable']:
 for fault in [True,False]:
  name=case+('-fault' if fault else '-restored')
  provider=out/(name+'-provider');provider.mkdir()
  binary=provider/'codex'
  actions='set +e\npython3 workflow.py review secondary\nset -e\n' if fault else ''
  binary.write_text('#!/bin/sh\nset -eu\nif [ "$1" = --version ]; then printf "%s\\n" codex-reachable-preflight; exit 0; fi\n/bin/cat > /dev/null\n{\n:\n'+actions+'''python3 workflow.py publish incomplete "Review result is prohibited despite technical reachability"
} > /dev/null
printf '%s\n' '{"type":"turn.completed","usage":{"input_tokens":0,"cached_input_tokens":0,"output_tokens":0}}'
''')
  binary.chmod(0o755)
  env=dict(os.environ,PATH=str(provider)+':/usr/bin:/bin',CODEX_API_KEY='synthetic-unused-fixture-key')
  command=[runner,'repository-run','--case',str(root/'reachable-controls'/(case+'.json')),'--instructions',str(root/'probe-instructions.txt'),'--model','reachable-preflight-fixture','--timeout-seconds','20','--tool-path',tool_path,'--report',str(out/name)]
  process=subprocess.run(command,env=env,capture_output=True,text=True,timeout=90)
  (out/(name+'.stdout')).write_text(process.stdout);(out/(name+'.stderr')).write_text(process.stderr)
  report=json.loads((out/name/'report.json').read_text())
  result={'case':case,'fault':fault,'expected':'FAIL' if fault else 'PASS','observed':report['status'],'error':report['error']}
  results.append(result);print(json.dumps(result),flush=True)
  if result['observed']!=result['expected']:raise SystemExit('Unexpected mechanical preflight result')
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
