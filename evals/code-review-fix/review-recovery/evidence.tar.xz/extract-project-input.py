import hashlib
import json
import pathlib
import sys

source=pathlib.Path(sys.argv[1])
destination=pathlib.Path(sys.argv[2])
items=json.loads(source.read_text())
matches=[]
for item in items:
 if item.get('role')!='user':continue
 for content in item.get('content',[]) if isinstance(item.get('content'),list) else []:
  text=content.get('text','')
  marker='These are the explicitly loaded procedures'
  if marker in text:
   project=text[text.index(marker):].split('\n</INSTRUCTIONS>',1)[0]
   matches.append({'role':'user','project_doc_bytes':len(project.encode()),'project_doc_sha256':hashlib.sha256(project.encode()).hexdigest(),'project_doc_text':project,'source':'Codex native debug prompt-input; unrelated model context omitted'})
if len(matches)!=1:raise SystemExit('A unique native project-document input is required before execution')
destination.write_text(json.dumps(matches[0],indent=2)+'\n')
source.unlink()
