import datetime
import hashlib
import json
import pathlib
import re
import subprocess

root = pathlib.Path('/Users/sebastien/.local/state/agent-skills-169/qualification-20261122.g9IwsX/neutral-runs')
plan = json.loads((root / 'invocation-plan.json').read_text())
mapping = json.loads((root / 'condition-map.json').read_text())
records = json.loads((root / 'execution-summary.json').read_text())
comparisons = {}
for case in plan['fixtures']:
    pair = {metadata['condition']: label for label, metadata in mapping.items() if metadata['case'] == case}
    args = [plan['runner'], 'repository-compare', str(root / pair['u']), str(root / pair['v'])]
    result = subprocess.run(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    value = {'argv': args, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    (root / (case + '-comparison.json')).write_text(json.dumps(value, indent=2) + '\n')
    comparisons[case] = value

totals = {}
rows = []
commands = []
packets = []
for record in records:
    usages = record.get('usage', [])
    usage = usages[-1] if usages else None
    row = {key: record[key] for key in ['label', 'case', 'condition', 'runner_status', 'runner_error', 'runner_process_finished', 'exit_code', 'seconds', 'started_utc', 'finished_utc']}
    row['usage'] = usage
    rows.append(row)
    aggregate = totals.setdefault(record['condition'], {'sessions': 0, 'process_seconds': 0, 'input_tokens': 0, 'cached_input_tokens': 0, 'output_tokens': 0, 'reasoning_output_tokens': 0})
    aggregate['sessions'] += 1
    aggregate['process_seconds'] += record['seconds']
    if usage:
        for key in ['input_tokens', 'cached_input_tokens', 'output_tokens', 'reasoning_output_tokens']:
            aggregate[key] += usage.get(key, 0)
    for line in (root / record['label'] / 'agent.jsonl').read_text().splitlines():
        event = json.loads(line)
        action = event.get('item', {})
        if event.get('type') == 'item.completed' and action.get('type') == 'command_execution':
            commands.append({'label': record['label'], 'case': record['case'], 'command': action.get('command', ''), 'exit_code': action.get('exit_code')})
for value in totals.values():
    value['process_seconds'] = round(value['process_seconds'], 3)
for case in plan['fixtures']:
    packets.extend(json.loads((root / (case + '-anonymous.json')).read_text()))
started = min(datetime.datetime.fromisoformat(value['started_utc']) for value in records)
finished = max(datetime.datetime.fromisoformat(value['finished_utc']) for value in records)
fingerprints = {
    'runner': hashlib.sha256(pathlib.Path(plan['runner']).read_bytes()).hexdigest(),
    'fixtures': {name: hashlib.sha256((root / (name + '.json')).read_bytes()).hexdigest() for name in plan['fixtures']},
    'instruction_bundles': {condition: hashlib.sha256((root.parent / (condition + '.txt')).read_bytes()).hexdigest() for condition in plan['instruction_hashes']},
}
unchanged = fingerprints['runner'] == plan['runner_hash'] and fingerprints['fixtures'] == plan['fixtures'] and fingerprints['instruction_bundles'] == plan['instruction_hashes']
metrics = {'environment': json.loads((root / 'environment.json').read_text()), 'wall_seconds': round((finished - started).total_seconds(), 3), 'totals': totals, 'rows': rows, 'post_run_fingerprints': fingerprints, 'all_inputs_and_runner_unchanged': unchanged, 'limitation': 'Native CLI observations with explicitly injected instructions. Facets require separate blind judgement. No automatic activation, cross-host, statistical or billing claim.'}
(root / 'metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
(root / 'comparisons.json').write_text(json.dumps(comparisons, indent=2) + '\n')
(root / 'all-anonymous.json').write_text(json.dumps(packets, indent=2) + '\n')
(root / 'command-inventory.json').write_text(json.dumps(commands, indent=2) + '\n')
patterns = ['.agents/skills', '.codex/skills', '.claude/skills', '/Users/sebastien/Code', '.codex/config', '.claude/settings', 'Path.home(', 'expanduser(', 'os.environ', 'getenv(', 'printenv', '$HOME', '${HOME}', 'find /Users', 'ls ~', 'npm install', 'bun add', 'pip install', 'pip3 install', 'codex exec', 'command -v codex', 'which codex']
indicators = []
for command in commands:
    matches = [pattern for pattern in patterns if pattern in command['command']]
    if matches:
        indicators.append({**command, 'indicators': matches})
inventory = {'commands_observed': len(commands), 'patterns': patterns, 'indicators': indicators, 'limitation': 'Inspection aid over executed command text only. Empty indicators do not prove technical isolation or absence of implicit host loading.'}
(root / 'contamination-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
print(json.dumps({'sessions': len(records), 'statuses': [record['runner_status'] for record in records], 'totals': totals, 'wall_seconds': metrics['wall_seconds'], 'unchanged': unchanged, 'commands_observed': len(commands), 'indicator_count': len(indicators)}))
